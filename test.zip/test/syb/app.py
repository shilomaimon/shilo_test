from flask import Flask, request, render_template
import sqlite3

app = Flask(__name__)

def init_db():
    conn = sqlite3.connect("users.db")
    c = conn.cursor()
    c.execute("CREATE TABLE IF NOT EXISTS users (id INTEGER PRIMARY KEY, username TEXT UNIQUE, email TEXT)")
    c.execute("DELETE FROM users")  # כדי לא לשכפל רשומות בכל הפעלה
    c.execute("INSERT INTO users (username, email) VALUES ('alice', 'alice@example.com')")
    c.execute("INSERT INTO users (username, email) VALUES ('bob', 'bob@example.com')")
    conn.commit()
    conn.close()

init_db()

@app.route("/", methods=["GET"])
def search_form():
    return render_template("search.html")

@app.route("/user", methods=['GET'])
def get_user():
    username = request.args.get("username")
    conn = sqlite3.connect("users.db")
    c = conn.cursor()
    c.execute("SELECT * FROM users WHERE username = ?", (username,))
    result = c.fetchone()
    conn.close()

    if result:
        user_dict = {"id": result[0], "username": result[1], "email": result[2]}
        # מחזיר את המידע ל-HTML
        return render_template("search.html", user=user_dict)
    else:
        # אם לא נמצא, מחזיר הודעה
        return render_template("search.html", error="User not found")

if __name__ == "__main__":
    app.run()
